<?php
add_action('admin_menu', 'clap_add_settings_page');

function clap_add_settings_page() {
    add_menu_page(
        'Login Alert Settings',
        'Login Alert',
        'manage_options',
        'clap-settings',
        'clap_render_settings_page',
        'dashicons-shield-alt'
    );
}

add_action('admin_enqueue_scripts', 'clap_admin_styles');
function clap_admin_styles() {
    wp_enqueue_style('clap-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');
}

function clap_render_settings_page() {
    ?>
    <div class="wrap">
        <h1>Custom Login Alert Pro Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('clap_settings_group');
            do_settings_sections('clap-settings');
            submit_button();
            ?>
        </form>
        <div class="clap-dev-credit">
            <p>Developed by <strong>Kamrul Hossain</strong></p>
            <p>
                <a href="https://kamrul.us" target="_blank"><i class="fas fa-globe"></i></a>
                <a href="https://github.com/kamrullab" target="_blank"><i class="fab fa-github"></i></a>
                <a href="https://facebook.com/elitekamrul" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://linkedin.com/in/kamrulofficial" target="_blank"><i class="fab fa-linkedin-in"></i></a>
            </p>
        </div>
    </div>
    <?php
}

add_action('admin_init', 'clap_register_settings');

function clap_register_settings() {
    register_setting('clap_settings_group', 'clap_settings');

    add_settings_section('clap_section', 'Notification Settings', null, 'clap-settings');

    add_settings_field('admin_email', 'Admin Email', 'clap_admin_email_field', 'clap-settings', 'clap_section');
    add_settings_field('whatsapp_number', 'WhatsApp Number', 'clap_whatsapp_number_field', 'clap-settings', 'clap_section');
    add_settings_field('whatsapp_api', 'WhatsApp API Key', 'clap_whatsapp_api_field', 'clap-settings', 'clap_section');
    add_settings_field('messenger_user', 'Messenger Username', 'clap_messenger_user_field', 'clap-settings', 'clap_section');
    add_settings_field('messenger_api', 'Messenger API Key', 'clap_messenger_api_field', 'clap-settings', 'clap_section');
    add_settings_field('notification_mode', 'Notification Modes', 'clap_notification_mode_field', 'clap-settings', 'clap_section');
    add_settings_field('custom_message', 'Custom Message Template', 'clap_custom_message_field', 'clap-settings', 'clap_section');
}

function clap_admin_email_field() {
    $options = get_option('clap_settings');
    echo '<input type="email" name="clap_settings[admin_email]" value="' . esc_attr($options['admin_email'] ?? '') . '" size="40">';
}

function clap_whatsapp_number_field() {
    $options = get_option('clap_settings');
    echo '<input type="text" name="clap_settings[whatsapp_number]" value="' . esc_attr($options['whatsapp_number'] ?? '') . '" size="40">';
    echo '<p><small>Format: +8801XXXXXXXXX</small></p>';
}

function clap_whatsapp_api_field() {
    $options = get_option('clap_settings');
    echo '<input type="text" name="clap_settings[whatsapp_api]" value="' . esc_attr($options['whatsapp_api'] ?? '') . '" size="40">';
    echo '<p><small>Get API Key: <a href="https://www.callmebot.com/faq/" target="_blank">CallMeBot FAQ</a></small></p>';
}

function clap_messenger_user_field() {
    $options = get_option('clap_settings');
    echo '<input type="text" name="clap_settings[messenger_user]" value="' . esc_attr($options['messenger_user'] ?? '') . '" size="40">';
    echo '<p><small>Example: @your.fb.username</small></p>';
}

function clap_messenger_api_field() {
    $options = get_option('clap_settings');
    echo '<input type="text" name="clap_settings[messenger_api]" value="' . esc_attr($options['messenger_api'] ?? '') . '" size="40">';
    echo '<p><small>Get API Key: <a href="https://www.callmebot.com/blog/free-api-facebook-messenger/" target="_blank">CallMeBot Messenger Setup</a></small></p>';
}

function clap_notification_mode_field() {
    $options = get_option('clap_settings');
    $modes = $options['notification_mode'] ?? [];

    $checked = function($val) use ($modes) {
        return in_array($val, (array)$modes) ? 'checked' : '';
    };

    echo '<label><input type="checkbox" name="clap_settings[notification_mode][]" value="email" ' . $checked('email') . '> Email</label><br>';
    echo '<label><input type="checkbox" name="clap_settings[notification_mode][]" value="whatsapp" ' . $checked('whatsapp') . '> WhatsApp</label><br>';
    echo '<label><input type="checkbox" name="clap_settings[notification_mode][]" value="messenger" ' . $checked('messenger') . '> Messenger</label>';
}

function clap_custom_message_field() {
    $options = get_option('clap_settings');
    echo '<textarea name="clap_settings[custom_message]" rows="6" cols="60">' . esc_textarea($options['custom_message'] ?? '') . '</textarea>';
    echo '<p><small>Available: {username}, {email}, {ip}, {browser}, {time}, {country}</small></p>';
}
?>
