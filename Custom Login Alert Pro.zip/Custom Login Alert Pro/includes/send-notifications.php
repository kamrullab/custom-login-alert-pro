<?php
// === Send Email ===
function clap_send_email_notification($message) {
    $options = get_option('clap_settings');
    $to = $options['admin_email'] ?? '';
    $subject = 'Login Alert - Custom Login Alert Pro';
    if (!empty($to)) {
        wp_mail($to, $subject, $message);
    }
}

// === Send WhatsApp ===
function clap_send_whatsapp_notification($message) {
    $options = get_option('clap_settings');
    $phone = $options['whatsapp_number'] ?? '';
    $apikey = $options['whatsapp_api'] ?? '';
    if (!empty($phone) && !empty($apikey)) {
        $url = "https://api.callmebot.com/whatsapp.php?phone=" . urlencode($phone)
             . "&text=" . urlencode($message)
             . "&apikey=" . urlencode($apikey);
        wp_remote_get($url);
    }
}

// === Send Messenger ===
function clap_send_messenger_notification($message) {
    $options = get_option('clap_settings');
    $user = $options['messenger_user'] ?? '';
    $apikey = $options['messenger_api'] ?? '';
    if (!empty($user) && !empty($apikey)) {
        $url = "https://api.callmebot.com/facebook/send.php?user=" . urlencode($user)
             . "&text=" . urlencode($message)
             . "&apikey=" . urlencode($apikey);
        wp_remote_get($url);
    }
}

// === Get Country from IP ===
function clap_get_country_from_ip($ip) {
    $response = wp_remote_get("http://ip-api.com/json/{$ip}");
    if (is_wp_error($response)) return 'Unknown';
    $data = json_decode(wp_remote_retrieve_body($response));
    if (!empty($data) && $data->status === 'success') {
        return country_flag_emoji($data->countryCode) . ' ' . $data->country;
    }
    return 'Unknown';
}

// === Convert Country Code to Flag Emoji ===
function country_flag_emoji($countryCode) {
    if (strlen($countryCode) != 2) return '';
    $offset = 127397;
    return mb_convert_encoding(
        '&#' . (ord($countryCode[0]) + $offset) . ';' .
        '&#' . (ord($countryCode[1]) + $offset) . ';',
        'UTF-8',
        'HTML-ENTITIES'
    );
}
?>
