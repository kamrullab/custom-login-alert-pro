<?php
// Save Login History
function clap_save_login_history($username, $ip, $country, $status) {
    $history = get_option('clap_login_history', []);
    $history[] = [
        'user' => $username,
        'ip' => $ip,
        'country' => $country,
        'status' => $status,
        'time' => current_time('mysql')
    ];
    if (count($history) > 20) {
        array_shift($history); // Keep last 20
    }
    update_option('clap_login_history', $history);
}

// Add Dashboard Widget
add_action('wp_dashboard_setup', 'clap_add_dashboard_widget');

function clap_add_dashboard_widget() {
    wp_add_dashboard_widget('clap_login_history', 'Recent Login Activity', 'clap_show_login_history');
}

// Display Login History
function clap_show_login_history() {
    $history = get_option('clap_login_history', []);
    if (empty($history)) {
        echo "<p>No login activity recorded yet.</p>";
        return;
    }

    echo "<table style='width:100%; border-collapse:collapse;'>";
    echo "<tr><th>User</th><th>IP</th><th>Country</th><th>Status</th><th>Time</th></tr>";

    foreach (array_reverse($history) as $entry) {
        echo "<tr>";
        echo "<td>" . esc_html($entry['user']) . "</td>";
        echo "<td>" . esc_html($entry['ip']) . "</td>";
        echo "<td>" . esc_html($entry['country']) . "</td>";
        echo "<td>" . esc_html($entry['status']) . "</td>";
        echo "<td>" . esc_html($entry['time']) . "</td>";
        echo "</tr>";
    }

    echo "</table>";
}
?>
