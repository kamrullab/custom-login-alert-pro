<?php
/**
 * Plugin Name: Custom Login Alert Pro
 * Plugin URI: 
 * Description: Sends real-time Email, WhatsApp, and Messenger notifications on login success/failure. Supports emoji, country flags, custom templates, login history, and multilingual (Bangla & English) auto switch.
 * Version: 1.3.0
 * Author: Kamrul Hossain
 * Author URI: https://kamrul.us/
 * License: GPL2
 * Text Domain: custom-login-alert-pro
 */

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'admin/settings-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/send-notifications.php';
require_once plugin_dir_path(__FILE__) . 'includes/login-history.php';

// Load CSS
add_action('admin_enqueue_scripts', 'clap_load_admin_styles');
function clap_load_admin_styles() {
    wp_enqueue_style('clap-style', plugin_dir_url(__FILE__) . 'assets/style.css');
}

// Multilingual Default Message Based on Site Language
function clap_get_default_message() {
    return get_locale() === 'bn_BD'
        ? "🔐 নতুন লগইন ডিটেলস:\n\n👤 নাম: {username}.\n\n📧 ইমেইল: {email}.\n\n🌐 আইপি: {ip}.\n\n🏳️ দেশ: {country}.\n\n💻 ডিভাইস/ব্রাউজার: {browser}.\n\n⏰ সময়: {time}."
        : "🔐 New login details:\n\n👤 Name: {username}.\n\n📧 Email: {email}.\n\n🌐 IP: {ip}.\n\n🏳️ Country: {country}.\n\n💻 Device/Browser: {browser}.\n\n⏰ Time: {time}.";
}

// Plugin Activation Hook
register_activation_hook(__FILE__, 'clap_plugin_activate');
function clap_plugin_activate() {
    if (!get_option('clap_settings')) {
        add_option('clap_settings', [
            'admin_email' => get_option('admin_email'),
            'notification_mode' => ['email'],
            'custom_message' => clap_get_default_message()
        ]);
    }
    if (!get_option('clap_login_history')) {
        add_option('clap_login_history', []);
    }
}

// Handle Successful Login
add_action('wp_login', 'clap_handle_success_login', 10, 2);
function clap_handle_success_login($user_login, $user) {
    $options = get_option('clap_settings');
    if (!$options) return;

    $modes = $options['notification_mode'] ?? [];
    $ip = $_SERVER['REMOTE_ADDR'];
    $country = clap_get_country_from_ip($ip);
    $template = $options['custom_message'] ?? '';

    $placeholders = [
        '{username}' => $user_login,
        '{email}'    => $user->user_email,
        '{ip}'       => $ip,
        '{browser}'  => $_SERVER['HTTP_USER_AGENT'],
        '{time}'     => current_time('mysql'),
        '{country}'  => $country,
    ];

    $message = strtr($template, $placeholders);

    if (in_array('email', $modes))     clap_send_email_notification($message);
    if (in_array('whatsapp', $modes))  clap_send_whatsapp_notification($message);
    if (in_array('messenger', $modes)) clap_send_messenger_notification($message);

    clap_save_login_history($user_login, $ip, $country, 'Success');
}

// Handle Failed Login
add_action('wp_login_failed', 'clap_handle_failed_login');
function clap_handle_failed_login($username) {
    $options = get_option('clap_settings');
    if (!$options) return;

    $modes = $options['notification_mode'] ?? [];
    $ip = $_SERVER['REMOTE_ADDR'];
    $country = clap_get_country_from_ip($ip);
    $message = get_locale() === 'bn_BD'
        ? "❌ লগইন ব্যর্থ!\n\nইউজারনেম: {$username}\n\nআইপি: {$ip} ({$country})\n\nসময়: " . current_time('mysql')
        : "❌ Login Failed!\n\nUsername: {$username}\n\nIP: {$ip} ({$country})\n\nTime: " . current_time('mysql');

    if (in_array('email', $modes))     clap_send_email_notification($message);
    if (in_array('whatsapp', $modes))  clap_send_whatsapp_notification($message);
    if (in_array('messenger', $modes)) clap_send_messenger_notification($message);

    clap_save_login_history($username, $ip, $country, 'Failed');
}

// Custom Links Under Plugin Name
add_filter('plugin_row_meta', 'clap_custom_plugin_links', 10, 2);
function clap_custom_plugin_links($links, $file) {
    if (strpos($file, 'custom-login-alert-pro.php') !== false) {
        $custom_links = [
            '<a href="https://kamrul.us/plugins/custom-login-alert-pro" target="_blank"><strong>Visit</strong></a>',
            '<a href="https://github.com/kamrullab/custom-login-alert-pro" target="_blank">GitHub</a>',
            '<a href="https://facebook.com/elitekamrul" target="_blank">Facebook</a>',
        ];
        return array_merge($links, $custom_links);
    }
    return $links;
}
?>
