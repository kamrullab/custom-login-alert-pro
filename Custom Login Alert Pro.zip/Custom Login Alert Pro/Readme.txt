=== Custom Login Alert Pro ===
Contributors: kamrullab
Tags: login alert, email notification, whatsapp, messenger, country flag, bangla, multi-language
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Custom Login Alert Pro is a multilingual WordPress plugin that sends real-time login notifications via Email, WhatsApp, and Facebook Messenger.  
Supports custom message template with emoji, country flag, IP tracking, and dynamic Bangla/English language switching.

== Features ==

* 🔔 Real-time login alerts (success + failure)
* ✉️ Email, 📱 WhatsApp, and 💬 Messenger notifications
* 🌍 IP-based country detection with flag emoji
* 📝 Customizable message templates with variables:
  - {username}, {email}, {ip}, {country}, {browser}, {time}
* 📊 Dashboard login activity history
* 🌐 Bangla & English auto language switch
* 💬 FontAwesome styled developer credit section
* 🛠️ No config required — ready in 2 minutes!

== Installation ==

1. Upload the plugin folder `custom-login-alert-pro` to `/wp-content/plugins/`
2. Activate the plugin via Plugins menu in WordPress
3. Go to Dashboard > Login Alert and configure your settings

== Frequently Asked Questions ==

= Does it support Bangla messages? =
Yes! If your site language is set to বাংলা (bn_BD), all templates and messages will automatically show in Bangla.

= Can I use only email, or only WhatsApp? =
Yes. You can choose 1, 2, or all 3 methods from the settings panel.

= Is WhatsApp and Messenger free? =
Yes. It uses [CallMeBot](https://www.callmebot.com/) API which provides free message sending for personal use.

== Screenshots ==

1. Admin settings with WhatsApp, Messenger, and Email fields
2. Notification example with emoji and flag
3. Dashboard login history with IP and device

== Changelog ==

= 1.3.0 =
* Added multilingual (Bangla/English) dynamic support
* Improved message formatting with spacing

= 1.2.0 =
* Added Messenger support
* FontAwesome developer credit icons

= 1.1.0 =
* Added login history widget
* Failed login detection

= 1.0.0 =
* Initial release with email + WhatsApp alert

== Upgrade Notice ==
Switching to 1.3.0 will auto-activate multilingual message formatting. Re-check your template if customized.

== License ==
This plugin is licensed under the GPL v2 or later.
Copyright (c) 2024 Kamrul
